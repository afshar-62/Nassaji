# Taropod - Profile / Identity Vertical Slice

این پکیج شامل کلیه کدهای فرانت‌اند، بک‌اند، روت‌ها، سرویس، ریپازیتوری و تست‌های هویت حرفه‌ای (Profile Slice) تاروپود است.